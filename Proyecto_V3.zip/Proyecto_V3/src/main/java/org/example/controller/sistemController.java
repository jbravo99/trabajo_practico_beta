package org.example.controller;
import org.example.model.exoplanetaHandler;
import org.example.model.exoplaneta;
import org.example.model.satelitesHandler;
import org.example.model.interferencia;
import org.example.model.reconstructor;
import org.example.model.ubicarExoplaneta;
import org.example.model.satelites;

public class sistemController {
    private static final exoplanetaHandler exoplanetaHandler = new exoplanetaHandler();
    private static final satelitesHandler satelitesHandler = new satelitesHandler();


    //Crear exoplaneta
    public static exoplaneta crearExoplaneta() {
        exoplaneta planetaNuevo = exoplanetaHandler.crearExoplaneta();
        return planetaNuevo;
    }

    //Crear satelites
    public static void crearSatelite() {
        String mensajeOriginal = exoplaneta.getMensaje();
        String mensaje = interferencia.interferenciaDelMensaje(mensajeOriginal);
        satelitesHandler.agregarSatelite(mensaje);
    }

    //Armo el mensaje en base a los recibidos con "inteferencia" en los distintos satelites
    public static String recontruirMensajePerdido(String mensaje1, String mensaje2, String mensaje3) {
        String mensajeReconstruido = reconstructor.reconstruccion(mensaje1, mensaje2, mensaje3);
        return mensajeReconstruido;
    }


    //Obtener ubicacion del exoplaneta en base a los satelites ingresados,
    //se utilizan las coordenadas de tres satélites y sus distancias al exoplaneta
    //para estimar la ubicación del exoplaneta. El metodo aplicado es el de posición de intersección de esferas.
    public double[] ubicacionExoplaneta(satelites Satelite1, satelites Satelite2, satelites Satelite3){
        return ubicarExoplaneta.trilateracion(Satelite1,Satelite2,Satelite3);
    }

}

