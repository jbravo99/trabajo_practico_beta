package org.example.controller;

import org.example.model.satelites;
import org.example.model.satelitesHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/satelites")
public class SatelitesController {
    private final satelitesHandler handler;

    public SatelitesController(satelitesHandler handler) {
        this.handler = handler;
    }

    @GetMapping
    public List<satelites> getSatelites() {
        return handler.satelites;
    }
}