package org.example.model;

import java.util.Scanner;

public class exoplaneta {

    public static String mensaje;
    public static String name;
    // Constructor que solicita al usuario ingresar un texto
    public exoplaneta(String name) {
        solicitarMensaje();
        this.name = name;
    }

    // Método para solicitar al usuario ingresar un mensaje
    private void solicitarMensaje() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese el mensaje para el exoplaneta:");
        mensaje = scanner.nextLine();
    }

    public static String getMensaje() {
        return mensaje;
    }

    public static String getName(){
        return name;
    }


}
