package org.example.model;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class reconstructor {

    public static String reconstruccion(String fuente1, String fuente2, String fuente3) {
        // Dividir las cadenas de fuente en listas de palabras
        List<String> listaFuente1 = Arrays.asList(fuente1.split("\\s+"));
        List<String> listaFuente2 = Arrays.asList(fuente2.split("\\s+"));
        List<String> listaFuente3 = Arrays.asList(fuente3.split("\\s+"));

        // Longitud máxima de las tres fuentes
        int maxLength = Math.max(Math.max(listaFuente1.size(), listaFuente2.size()), listaFuente3.size());

        StringBuilder mensajeReconstruido = new StringBuilder();

        // Mantener un registro de la última palabra agregada al mensaje
        String ultimaPalabra = "";

        for (int i = 0; i < maxLength; i++) {
            String palabraActual = "";

            if (i < listaFuente1.size()) {
                palabraActual = listaFuente1.get(i);
            }

            if (i < listaFuente2.size() && !listaFuente2.get(i).equals(ultimaPalabra)) {
                palabraActual = listaFuente2.get(i);
            }

            if (i < listaFuente3.size() && !listaFuente3.get(i).equals(ultimaPalabra)) {
                palabraActual = listaFuente3.get(i);
            }

            // Verificar si la palabra actual es diferente a la última palabra agregada
            if (!palabraActual.isEmpty() && !palabraActual.equals(ultimaPalabra)) {
                mensajeReconstruido.append(palabraActual).append(" ");
                ultimaPalabra = palabraActual;
            }
        }

        if (mensajeReconstruido.length() > 0) {
            // Eliminar el espacio final
            mensajeReconstruido.deleteCharAt(mensajeReconstruido.length() - 1);
        }

        return mensajeReconstruido.toString();
    }

}
