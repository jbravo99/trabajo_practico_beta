package org.example.model;
import java.util.Scanner;

     public class ubicarExoplaneta {

         public static double[] trilateracion(satelites satelite1, satelites satelite2, satelites satelite3) {
             double[] ubicacionExoplaneta = trilaterar(
                     satelite1.getUbicacion(), satelite1.getDistancia(),
                     satelite2.getUbicacion(), satelite2.getDistancia(),
                     satelite3.getUbicacion(), satelite3.getDistancia()
             );

             return ubicacionExoplaneta;
             // Mostrar la ubicación estimada del exoplaneta

         }

         private static double[] trilaterar(double[] ubicacionSatelite1, double distanciaSatelite1,
                                            double[] ubicacionSatelite2, double distanciaSatelite2,
                                            double[] ubicacionSatelite3, double distanciaSatelite3) {
             double x1 = ubicacionSatelite1[0];
             double y1 = ubicacionSatelite1[1];
             double x2 = ubicacionSatelite2[0];
             double y2 = ubicacionSatelite2[1];
             double x3 = ubicacionSatelite3[0];
             double y3 = ubicacionSatelite3[1];

             double d1 = distanciaSatelite1;
             double d2 = distanciaSatelite2;
             double d3 = distanciaSatelite3;

             // Calcular las diferencias entre las coordenadas de los satélites
             double dx1 = x2 - x1;
             double dy1 = y2 - y1;
             double dx2 = x3 - x1;
             double dy2 = y3 - y1;

             // Calcular las ecuaciones para encontrar la ubicación del exoplaneta
             double a = (d1 * d1 - d2 * d2 - dx1 * dx1 - dy1 * dy1 + dx2 * dx2 + dy2 * dy2) / 2;
             double b = (d2 * d2 - d3 * d3 - dx2 * dx2 - dy2 * dy2) / 2;

             double x = (a * dy2 - b * dy1) / (dx1 * dy2 - dx2 * dy1);
             double y = (a - x * dx1) / dy1;

             return new double[]{x, y};
         }


     }
