package org.example.model;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class exoplanetaHandler {
    public static exoplaneta crearExoplaneta() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese el nombre del exoplaneta:");
        String nombre = scanner.nextLine();

        // Crear un nuevo exoplaneta solicitando el mensaje al usuario
        exoplaneta exoplaneta = new exoplaneta(nombre);
        return exoplaneta;
    }

}
