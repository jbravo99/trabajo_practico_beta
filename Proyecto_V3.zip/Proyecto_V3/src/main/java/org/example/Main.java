package org.example;
import org.example.controller.sistemController;
import org.example.model.exoplaneta;
import java.util.Scanner;
import org.example.model.*;
import java.util.ArrayList;
import java.util.List.*;

public class Main {
    public static void main(String[] args) {
        sistemController.crearExoplaneta();
        System.out.println("Agregar tres satelites");
        for (int i = 0; i < 3; i++) {
            // Acción x que se repetirá 3 veces
            sistemController.crearSatelite();
        }
        satelitesHandler handler = new satelitesHandler();
        satelites SateliteA = handler.satelites.get(0);
        satelites SateliteB = handler.satelites.get(1);
        satelites SateliteC = handler.satelites.get(2);

        Scanner scanner = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("\nMenú:");
            System.out.println("1. Obtener ubicación del exoplaneta en base a satélites");
            System.out.println("2. Armar mensaje para el exoplaneta");
            System.out.println("3. Mostrar información de los satélites");
            System.out.println("4. Mostrar información del exoplaneta");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opción: ");

            opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    double[] ubicacionDescubierta = ubicarExoplaneta.trilateracion(SateliteA, SateliteB, SateliteC);
                    System.out.println("Ubicación estimada del exoplaneta: [" + ubicacionDescubierta[0] + ", " + ubicacionDescubierta[1] + "]");
                    break;
                case 2:
                    String mensajeExoplaneta = sistemController.recontruirMensajePerdido(SateliteA.getMensaje(),SateliteB.getMensaje(),SateliteC.getMensaje());
                    System.out.println("Mensaje del exoplaneta: " + mensajeExoplaneta);
                    break;
                case 3:
                    SateliteA.mostrarInformacion();
                    SateliteB.mostrarInformacion();
                    SateliteC.mostrarInformacion();
                    break;
                case 4:
                    String mensajeExoplanetaInfo = exoplaneta.getMensaje();
                    System.out.println("Nombre del exoplaneta: " + exoplaneta.getName());
                    System.out.println("Mensaje del exoplaneta: " + mensajeExoplanetaInfo);
                    break;
                case 0:
                    System.out.println("Saliendo del programa.");
                    break;
                default:
                    System.out.println("Opción no válida. Intente nuevamente.");
            }

        } while (opcion != 0);
    }



}