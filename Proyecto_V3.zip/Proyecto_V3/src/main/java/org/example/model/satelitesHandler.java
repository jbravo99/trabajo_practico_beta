package org.example.model;

import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

@Component

public class satelitesHandler {
    public static List<satelites> satelites = new ArrayList<>();

    // Constructor sin parámetros
    public void SatelitesHandler() {
        this.satelites = new ArrayList<>();
    }

    public void agregarSatelite(String mensaje) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese el nombre del satélite:");
        String nombre = scanner.nextLine();
        System.out.println("Ingrese la distancia satélite-exoplaneta:");
        double distancia = scanner.nextDouble();
        System.out.println("Ingrese la ubicación del satélite (coordenada x):");
        double x = scanner.nextDouble();
        System.out.println("Ingrese la ubicación del satélite (coordenada y):");
        double y = scanner.nextDouble();

        double[] ubicacion = { x, y };

        // Crear un nuevo satélite con el mensaje modificado por interferencia
        satelites satelite = new satelites(nombre, distancia, ubicacion, mensaje);
        satelites.add(satelite);

        System.out.println("Satélite agregado correctamente.");
    }

    public void mostrarSatelites() {
        for (satelites satelite : satelites) {
            satelite.mostrarInformacion();
            System.out.println();
        }
    }

}
