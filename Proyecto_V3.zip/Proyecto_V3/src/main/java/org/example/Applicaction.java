package org.example;
import org.example.controller.sistemController;
import org.example.model.exoplaneta;
import java.util.Scanner;
import org.example.model.*;
import java.util.ArrayList;
import java.util.List.*;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Applicaction {

    public static void main(String[] args) {
        //Agrego un exoplaneta para que los satelites tengan un mensaje
        sistemController.crearExoplaneta();
        System.out.println("Agregar tres satelites");
        for (int i = 0; i < 3; i++) {
            // Acción x que se repetirá 3 veces
            sistemController.crearSatelite();
        }
        satelitesHandler handler = new satelitesHandler();
        satelites SateliteA = handler.satelites.get(0);
        satelites SateliteB = handler.satelites.get(1);
        satelites SateliteC = handler.satelites.get(2);

        SpringApplication.run(Applicaction.class, args);
    }
}
