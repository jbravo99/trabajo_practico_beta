package org.example.model;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.Random;

public class interferencia {

    public static String interferenciaDelMensaje(String mensaje) {
        // Dividir el mensaje en palabras
        String[] palabras = mensaje.split("\\s+");

        // Determinar la cantidad de palabras a modificar (máximo 20%)
        int cantidadPalabrasModificar = (int) Math.ceil(palabras.length * 0.2);

        // Obtener índices aleatorios de palabras a modificar
        List<Integer> indicesModificar = obtenerIndicesAleatorios(palabras.length, cantidadPalabrasModificar);

        // Modificar las palabras en los índices seleccionados
        for (int indice : indicesModificar) {
            palabras[indice] = modificarPalabra(palabras[indice]);
        }

        // Eliminar algunas palabras (máximo 20%)
        int cantidadPalabrasEliminar = (int) Math.ceil(palabras.length * 0.2);
        List<Integer> indicesEliminar = obtenerIndicesAleatorios(palabras.length, cantidadPalabrasEliminar);
        for (int indice : indicesEliminar) {
            palabras[indice] = "";
        }

        // Unir las palabras modificadas de nuevo en un mensaje
        return String.join(" ", palabras);
    }

    private static List<Integer> obtenerIndicesAleatorios(int maximo, int cantidad) {
        List<Integer> indices = Arrays.asList(new Integer[maximo]);
        for (int i = 0; i < maximo; i++) {
            indices.set(i, i);
        }
        Collections.shuffle(indices);
        return indices.subList(0, cantidad);
    }

    private static String modificarPalabra(String palabra) {
        // Agregar algunos espacios a la palabra
        palabra = agregarEspacios(palabra);

        // Puedes agregar más lógica de modificación según tus necesidades

        return palabra;
    }

    private static String agregarEspacios(String palabra) {
        // Agregar algunos espacios a la palabra
        Random random = new Random();
        int cantidadEspacios = random.nextInt(3) + 1; // Agregar entre 1 y 3 espacios
        StringBuilder palabraModificada = new StringBuilder();
        for (int i = 0; i < cantidadEspacios; i++) {
            palabraModificada.append(" ");
        }
        palabraModificada.append(palabra);
        return palabraModificada.toString();
    }

}
