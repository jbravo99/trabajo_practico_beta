package org.example.model;

public class satelites {
    private String name;
    private double distancia;
    private double[] ubicacion;  // Coordenadas [x, y]

    private String mensaje;

    //Constructor
    public satelites(String name, double distancia, double[] ubicacion,String mensaje ) {
        this.name = name;
        this.distancia = distancia;
        this.ubicacion = ubicacion;
        this.mensaje = mensaje;
    }

    // Métodos getter y setter para cada atributo
    public String getName() {
        return name;
    }

    public String getMensaje(){
        return mensaje;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getDistancia() {
        return distancia;
    }

    public void setDistancia(double distancia) {
        this.distancia = distancia;
    }

    public double[] getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(double[] ubicacion) {
        this.ubicacion = ubicacion;
    }

    // Método para mostrar la información del satélite
    public void mostrarInformacion() {
        System.out.println("\n**Nombre: " + name);
        System.out.println("**Distancia satelite-exoplaneta: " + distancia + " unidades astronómicas");
        System.out.println("**Ubicación del satelite: [" + ubicacion[0] + ", " + ubicacion[1] + "]");
        System.out.println("**Mensaje recibido: "+ mensaje);
    }

}
