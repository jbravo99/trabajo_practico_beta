En Proyecto_V2 se cargo la version con las clases principales en model y con un main que permite desplegar un menu
simple para realziar consultas en base a la informacion cargada,

En Proyecto_V3 se agregaron las dependencias necesarias, además de las clases SatelitesController y Application, para
asi utilizar el framework Springboot. De esta manera se tiene una clase llamada Application la cual permite
obtener mediante un get la informacion de los diferentes satelites.

Ejemplo de uso:

Al realizar una solicitud GET a http://localhost:8080/api/satelites,
podrías recibir una respuesta JSON que representa la lista de satélites.
Supongamos que estan estos tres satélites con información ficticia:

 [
     {
         "name": "SateliteA",
         "distancia": 10.5,
         "ubicacion": [20.0, 30.0],
         "mensaje": "Mensaje del SateliteA"
     },
     {
         "name": "SateliteB",
         "distancia": 15.2,
         "ubicacion": [25.0, 40.0],
         "mensaje": "Mensaje del SateliteB"
     },
     {
         "name": "SateliteC",
         "distancia": 12.8,
         "ubicacion": [22.0, 35.0],
         "mensaje": "Mensaje del SateliteC"
     }
 ]
